<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class Address
 * @package App\Models
 * @version January 28, 2022, 8:37 am UTC
 *
 * @property \Illuminate\Database\Eloquent\Collection $employees
 * @property string $title
 * @property integer $employee_id
 */
class Address extends Model
{
    use SoftDeletes;


    public $table = 'addresses';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'title',
        'employee_id'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'title' => 'string',
        'employee_id' => 'integer'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'title' => 'required',
        'employee_id' => 'required'
    ];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     **/
    public function employee()
    {
        return $this->belongsTo(\App\Models\Employee::class);
    }
}
