<?php

namespace App\Models;

use Eloquent as Model;
use Illuminate\Database\Eloquent\SoftDeletes;


/**
 * Class Employee
 * @package App\Models
 * @version January 28, 2022, 8:35 am UTC
 *
 * @property string $name
 */
class Employee extends Model
{
    use SoftDeletes;


    public $table = 'employees';


    protected $dates = ['deleted_at'];



    public $fillable = [
        'name'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'id' => 'integer',
        'name' => 'string'
    ];

    /**
     * Validation rules
     *
     * @var array
     */
    public static $rules = [
        'name' => 'required'
    ];
    public function employee(){
        return $this->hasOne(\App\Models\Address::class);
    }

}
