<!-- Name Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('name', 'Name:'); ?>

    <?php echo Form::text('name', null, ['class' => 'form-control']); ?>

</div>
<?php /**PATH E:\www\vegterence\resources\views/employees/fields.blade.php ENDPATH**/ ?>