

<li class="nav-item">
    <a href="<?php echo e(route('employees.index')); ?>"
       class="nav-link <?php echo e(Request::is('employees*') ? 'active' : ''); ?>">
        <p>Employees</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('addresses.index')); ?>"
       class="nav-link <?php echo e(Request::is('addresses*') ? 'active' : ''); ?>">
        <p>Addresses</p>
    </a>
</li>


<?php /**PATH E:\www\vegterence\resources\views/layouts/menu.blade.php ENDPATH**/ ?>