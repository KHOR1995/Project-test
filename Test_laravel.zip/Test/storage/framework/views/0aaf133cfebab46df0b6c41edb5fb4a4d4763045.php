<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH E:\www\vegterence\resources\views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>