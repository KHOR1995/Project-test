

<li class="nav-item">
    <a href="{{ route('employees.index') }}"
       class="nav-link {{ Request::is('employees*') ? 'active' : '' }}">
        <p>Employees</p>
    </a>
</li>


<li class="nav-item">
    <a href="{{ route('addresses.index') }}"
       class="nav-link {{ Request::is('addresses*') ? 'active' : '' }}">
        <p>Addresses</p>
    </a>
</li>


