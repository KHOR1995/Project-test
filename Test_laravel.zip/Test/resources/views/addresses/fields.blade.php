@php
    $data =[];
    if (isset($employees)) {
        foreach($employees as $employee){
            $data[$employee->id] = $employee->name;
        }

    }

@endphp
<!-- Employee Id Field -->
<div class="form-group col-sm-12">
    {!! Form::label('employee_id', 'Employees:') !!}
    {!! Form::select('employee_id',  $data, null, ['class' => 'form-control custom-select']) !!}
</div>

<!-- Title Field -->
<div class="form-group col-sm-12">
    {!! Form::label('title', 'Address:') !!}
    {!! Form::textarea('title', null, ['class' => 'form-control']) !!}
</div>

